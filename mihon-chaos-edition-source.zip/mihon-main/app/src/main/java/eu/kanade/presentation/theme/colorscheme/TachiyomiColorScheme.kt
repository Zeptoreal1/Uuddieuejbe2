package eu.kanade.presentation.theme.colorscheme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

/**
 * CHAOS EDITION: deliberately ugly, clashy and high-contrast defaults.
 * This is visual styling only. Reader rendering, downloaded data, and library
 * business logic remain untouched.
 */
internal object TachiyomiColorScheme : BaseColorScheme() {
    override val darkScheme = darkColorScheme(
        primary = Color(0xFFFF00C8),
        onPrimary = Color(0xFF16001F),
        primaryContainer = Color(0xFF8C0074),
        onPrimaryContainer = Color(0xFFFFE5FC),
        inversePrimary = Color(0xFF8F006E),
        secondary = Color(0xFF52F6FF),
        onSecondary = Color(0xFF002B32),
        secondaryContainer = Color(0xFF005F70),
        onSecondaryContainer = Color(0xFFB9FBFF),
        tertiary = Color(0xFFFFED00),
        onTertiary = Color(0xFF272000),
        tertiaryContainer = Color(0xFF655400),
        onTertiaryContainer = Color(0xFFFFFFB4),
        background = Color(0xFF150027),
        onBackground = Color(0xFFFCF588),
        surface = Color(0xFF240038),
        onSurface = Color(0xFFFFFFCA),
        surfaceVariant = Color(0xFF4B0053),
        onSurfaceVariant = Color(0xFFFFC9F2),
        surfaceTint = Color(0xFFFF00C8),
        inverseSurface = Color(0xFFF3F400),
        inverseOnSurface = Color(0xFF2A003B),
        error = Color(0xFFFF8B1C),
        onError = Color(0xFF281200),
        errorContainer = Color(0xFF933500),
        onErrorContainer = Color(0xFFFFE3BF),
        outline = Color(0xFF12EFFF),
        outlineVariant = Color(0xFF9A008E),
        surfaceContainerLowest = Color(0xFF120024),
        surfaceContainerLow = Color(0xFF36003F),
        surfaceContainer = Color(0xFF480052),
        surfaceContainerHigh = Color(0xFF64003E),
        surfaceContainerHighest = Color(0xFF003D5A),
    )

    override val lightScheme = lightColorScheme(
        primary = Color(0xFF6800B8),
        onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFFF8BE9),
        onPrimaryContainer = Color(0xFF410036),
        inversePrimary = Color(0xFFFF8BE9),
        secondary = Color(0xFFAD004A),
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFF00EFFF),
        onSecondaryContainer = Color(0xFF003343),
        tertiary = Color(0xFF005842),
        onTertiary = Color(0xFFFFFFFF),
        tertiaryContainer = Color(0xFFCAFF42),
        onTertiaryContainer = Color(0xFF183600),
        background = Color(0xFFDCFF4F),
        onBackground = Color(0xFF240035),
        surface = Color(0xFFFFFFBD),
        onSurface = Color(0xFF260038),
        surfaceVariant = Color(0xFFFFB4E1),
        onSurfaceVariant = Color(0xFF4A003B),
        surfaceTint = Color(0xFF6800B8),
        inverseSurface = Color(0xFF440057),
        inverseOnSurface = Color(0xFFFDFF67),
        error = Color(0xFF9C2B00),
        onError = Color(0xFFFFFFFF),
        errorContainer = Color(0xFFFFAC74),
        onErrorContainer = Color(0xFF4F1700),
        outline = Color(0xFF8600CC),
        outlineVariant = Color(0xFFFF38BB),
        surfaceContainerLowest = Color(0xFFFFFFE2),
        surfaceContainerLow = Color(0xFFFFE54B),
        surfaceContainer = Color(0xFFFFB3EF),
        surfaceContainerHigh = Color(0xFF8CFF64),
        surfaceContainerHighest = Color(0xFF75E7FF),
    )
}
